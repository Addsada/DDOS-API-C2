# AutoDumperV2
I didn't do much testing wit dis so if there are any errors lmk: Archs#7331

# What's New?
Added: 
```Better discord webhook support```
```Better UnderAttack Screen```
```Webhook: Most frequent attacking ip```
```Webhook: Attack protocols```
```Webhook: Attack Type```
```Webhook: Mbps & PPS Counter```
```Webhook: Established connections counter```
```Webhook: Attacking IPS Count```
# How to use
```
Create the following Folders: info , report , pcap , nigga , extra
```
```
You need python3 (usally comes with any ubuntu OS
```
```
#1 apt install tshark
```
```
#2 apt install wireshark
```
```
#3 apt install screen
```
```
#4 apt-get install python3-pip
```
```
#5 pip3 install requests
```
# Running AutoDumperV2
```
cd TCPDUMP
```
```
screen ./dumper.sh
```
```
ctrl a + d
```

# Preview

# Discord Webhook:
![image](https://user-images.githubusercontent.com/83051653/134649378-9946ee49-cfe3-454f-b327-826f0cbb8f05.png)

# UnderAttack Screen
![image](https://user-images.githubusercontent.com/83051653/134520659-1632f6d0-e8e7-4c7c-bbd4-c993ec65d8cb.png)

credit to SnoopDeveloper for attack types
